﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Plugins.Reports.ExportOrders
     * @function
     * 
     * @description
     * The controller for the reports Export Orders page
     */
    controllers.ExportOrdersController = function ($scope) {

        $scope.loaded = true;
        $scope.preValuesLoaded = true;

    };


    angular.module("umbraco").controller("Merchello.Plugins.Reports.ExportOrders", ['$scope', merchello.Controllers.ExportOrdersController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
