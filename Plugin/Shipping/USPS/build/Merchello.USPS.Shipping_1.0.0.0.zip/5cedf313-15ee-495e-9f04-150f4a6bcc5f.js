﻿/**
 * @ngdoc controller
 * @name Merchello.Plugin.GatewayProviders.Shipping.Dialogs.USPSShippingMethodController
 * @function
 * 
 * @description
 * The controller for the adding / editing shipping methods on the Shipping page
 */
angular.module('merchello.plugins.usps').controller('Merchello.Plugin.GatewayProviders.Shipping.Dialogs.USPSShippingMethodController',
    ['$scope',
        function ($scope) {

            var test = '';

        }]);