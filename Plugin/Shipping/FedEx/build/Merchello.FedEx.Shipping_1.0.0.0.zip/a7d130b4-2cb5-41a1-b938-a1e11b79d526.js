﻿/**
* @ngdoc controller
* @name Merchello.Plugin.GatewayProviders.Shipping.Dialogs.FedExShippingMethodController
* @function
* 
* @description
* The controller for the adding / editing payment methods on the Payment page
*/
angular.module('merchello.plugins.fedex').controller('Merchello.Plugin.GatewayProviders.Shipping.Dialogs.FedExShippingMethodController',
    ['$scope',
        function ($scope) {

            var test = '';

        }]);