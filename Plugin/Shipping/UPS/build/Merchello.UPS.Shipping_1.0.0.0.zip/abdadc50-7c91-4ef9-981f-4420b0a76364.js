﻿/**
 * @ngdoc controller
 * @name Merchello.Plugin.GatewayProviders.Shipping.Dialogs.UPSShippingMethodController
 * @function
 * 
 * @description
 * The controller for the adding / editing shipping methods on the Shipping page
 */
angular.module('merchello.plugins.ups').controller('Merchello.Plugin.GatewayProviders.Shipping.Dialogs.UPSShippingMethodController',
    ['$scope',
        function ($scope) {

            var test = '';

        }]);