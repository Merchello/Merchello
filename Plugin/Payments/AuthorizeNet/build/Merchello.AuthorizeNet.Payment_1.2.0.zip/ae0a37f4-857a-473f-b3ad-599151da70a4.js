﻿/**
 * @ngdoc controller
 * @name Merchello.Dashboards.Settings.Payment.Dialogs.PaymentMethodController
 * @function
 * 
 * @description
 * The controller for the adding / editing payment methods on the Payment page
 */
angular.module('merchello.plugins.authorizenet').controller('Merchello.Plugin.GatewayProviders.Payments.Dialogs.AuthorizeNetPaymentMethodController',
    ['$scope',
        function ($scope) {

        }]);