﻿/**
 * @ngdoc controller
 * @name Merchello.Plugin.GatewayProviders.Payments.Dialogs.ChasePaymentMethodController
 * @function
 * 
 * @description
 * The controller for the adding / editing payment methods on the Payment page
 */
angular.module('merchello.plugins.chase').controller('Merchello.Plugin.GatewayProviders.Payments.Dialogs.ChasePaymentMethodController',
    ['$scope',
        function ($scope) {

        }]);