﻿angular.module('merchello.plugins.braintree').controller('Merchello.Plugins.GatewayProviders.Dialogs.PaymentMethodAddEditController',
    ['$scope',
        function($scope) {

            console.info($scope.dialogData);

        }]);