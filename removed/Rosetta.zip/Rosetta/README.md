##Merchello Version
This site uses Merchello 1.5.1.2 

###Username
admin

###Password
1234
