﻿namespace Models
{
    public class CountryModel
    {
        public string CountryCode { get; set; }
        public string Name { get; set; } 
    }
}