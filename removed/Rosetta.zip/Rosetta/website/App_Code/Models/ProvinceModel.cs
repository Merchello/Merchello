﻿namespace Models
{
    public class ProvinceModel
    {
        public string ProvinceCode { get; set; }
        public string Name { get; set; }
    }
}