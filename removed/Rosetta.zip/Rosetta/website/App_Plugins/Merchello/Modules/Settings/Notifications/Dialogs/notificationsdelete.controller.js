﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Dashboards.Settings.Notifications.Dialogs.NotificationsDeleteController
     * @function
     * 
     * @description
     * The controller for the adding / editing Notification methods on the Notifications page
     */
    controllers.NotificationsDeleteController = function ($scope) {


    };

    angular.module("umbraco").controller("Merchello.Dashboards.Settings.Notifications.Dialogs.NotificationsDeleteController", ['$scope', merchello.Controllers.NotificationsDeleteController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
