﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Dashboards.Settings.Payment.Dialogs.PaymentDeleteController
     * @function
     * 
     * @description
     * The controller for the deleting payment methods on the Payment page
     */
    controllers.DeleteController = function ($scope) {


    };

    angular.module("umbraco").controller("Merchello.Common.Dialogs.DeleteController", ['$scope', merchello.Controllers.DeleteController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
